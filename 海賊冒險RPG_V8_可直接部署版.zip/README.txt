V8 海賊冒險 RPG

部署方式：把本資料夾內的 index.html 上傳到 GitHub pirate-rpg 儲存庫根目錄，覆蓋原本的 index.html。

版本標記：V8 實機規則版
Lv1 普攻：5～8
Lv2 普攻：6～9
Lv3 普攻：7～10
普攻不再套用暴擊倍數。
